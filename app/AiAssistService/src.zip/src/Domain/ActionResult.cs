﻿namespace Insurance.AiAssistService.Domain;

public class ActionResult
{
    public bool Success { get; set; }
    public string Message { get; set; }
}