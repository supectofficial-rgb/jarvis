﻿namespace Insurance.AiAssistService.AppServices;

public class LoginByCredentialDto
{
    public string? UserName { get; set; }
    public string? Password { get; set; }
}